from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import pandas as pd
import matplotlib.pyplot as plt
import pymongo
import os


app = Flask(__name__)

# Establish a connection to MongoDB
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["data_collection_db"]
data_collection = db["data"]

# This list will be used to store the data temporarily during the server runtime
data_list = []

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/form')
def form():
    return render_template('form.html')
@app.route('/excel')
def upload():
    return render_template('upload.html')

@app.route('/submit_form', methods=['POST'])
def submit_form():
    name = request.form['name']
    age = request.form['age']
    gender = request.form['sex']
    occupation = request.form['work']
    income = request.form['salary']

    # Append the data to the list
    data_list.append([name, age, gender, occupation, income])

    process_data_and_generate_charts()

    # Save the data to MongoDB
    data_collection.insert_one({
        'Name': name,
        'Age': age,
        'Gender': gender,
        'Occupation': occupation,
        'Income': income
    })

    return display_result()

@app.route('/submit_excel', methods=['POST'])
def submit_excel():
    # Check if a file was uploaded
    if 'file' not in request.files:
        return "No file uploaded."

    file = request.files['file']

    # Check if the file has an allowed extension
    if file and allowed_file(file.filename):
        # Save the file to a temporary location
        filename = secure_filename(file.filename)
        file_path = os.path.join('uploads', filename)
        file.save(file_path)

        # Read data from the Excel file
        df = pd.read_excel(file_path)

        # Append the data to the list
        data_list.extend(df.values.tolist())

        process_data_and_generate_charts()

        # Save the data to MongoDB
        data_collection.insert_many(df.to_dict('records'))

        return display_result()
    else:
        return "Invalid file. Only .xls or .xlsx files are allowed."


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in {'xls', 'xlsx'}

def process_data_and_generate_charts():
    # Perform data analysis
    df = pd.DataFrame(data_list, columns=['Name', 'Age', 'Gender', 'Occupation', 'Income'])
    occupation_counts = df['Occupation'].value_counts()

    # Create a pie chart for occupation distribution
    plt.figure(figsize=(6, 6))
    plt.pie(occupation_counts, labels=occupation_counts.index, autopct='%1.1f%%')
    plt.title('Occupation Distribution')
    plt.savefig('static/pie_chart.png')

    # Create a bar chart for age distribution
    age_counts = df['Age'].value_counts()
    plt.figure(figsize=(6, 6))
    plt.bar(age_counts.index, age_counts.values)
    plt.xlabel('Age Group')
    plt.ylabel('Count')
    plt.title('Age Distribution')
    plt.savefig('static/age_chart.png')

    # Create a bar chart for salary distribution
    salary_counts = df['Income'].value_counts()
    plt.figure(figsize=(8, 8))
    plt.bar(salary_counts.index, salary_counts.values)
    plt.xlabel('Salary Group')
    plt.ylabel('Count')
    plt.title('Salary Distribution')
    plt.savefig('static/salary_chart.png')

def display_result():
    df = pd.DataFrame(data_list, columns=['Name', 'Age', 'Gender', 'Occupation', 'Income'])
    return render_template(
        'result.html',
        data=df.to_html(),
        chart='static/pie_chart.png',
        age_chart='static/age_chart.png',
        salary_chart='static/salary_chart.png'
    )


if __name__ == '__main__':
    if not os.path.exists('uploads'):
        os.makedirs('uploads')
    app.run(debug=True)
